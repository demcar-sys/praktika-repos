from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Student, Teacher, Grade

@login_required
def dashboard(request):
    context = {}
    
    # Проверяем является ли пользователь студентом
    if hasattr(request.user, 'student'):
        student = request.user.student
        context['user_type'] = 'student'
        context['student'] = student
        context['grades'] = Grade.objects.filter(student=student)
    
    # Проверяем является ли пользователь преподавателем
    elif hasattr(request.user, 'teacher'):
        context['user_type'] = 'teacher'
        context['teacher'] = request.user.teacher
        context['students'] = Student.objects.all()
    
    # Если не студент и не преподаватель - администратор
    else:
        context['user_type'] = 'admin'
    
    return render(request, 'dashboard.html', context)