from django.urls import path
from . import views

urlpatterns = [
    path('grades/', views.dashboard, name='student_grades'),
]