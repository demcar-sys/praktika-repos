from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student')
    student_id = models.CharField(max_length=20, unique=True)
    
    class Meta:
        db_table = 'journal_student'
    
    def __str__(self):
        return f"{self.user.get_full_name()} ({self.student_id})"

class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='teacher')
    
    class Meta:
        db_table = 'journal_teacher'
    
    def __str__(self):
        return self.user.get_full_name()

class Grade(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    discipline = models.CharField(max_length=100)
    value = models.IntegerField(
        validators=[MinValueValidator(2), MaxValueValidator(5)],
        choices=[(2, '2'), (3, '3'), (4, '4'), (5, '5')]
    )
    date = models.DateField(auto_now_add=True)
    
    class Meta:
        db_table = 'journal_grade'
    
    def __str__(self):
        return f"{self.student} - {self.discipline} - {self.value}"